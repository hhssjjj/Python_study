
# 제2장 연습문제 1번
su = 5
dan = 800

print("su 주소 : " ,id(su))
print("dan 주소 : ",id(dan))
print("금액 = ",su*dan)

# 연습문제 2번
x = 2
y = 2.5*x**2+3.3*2+6
print(y)

# 연습문제 3번
n1 = (input("지방의 그램을 입력하세요 : "))
n2 = (input("탄수화물의 그램을 입력하세요 : "))
n3 = (input("단백질의 그램을 입력하세요 : "))
print( int(n1)*9+int(n2)*4+int(n3)*4)

