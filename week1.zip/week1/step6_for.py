
# for 반복문
lst = [1,2,3,4,5,10]
for i in lst:
    print(i)

for no in range(1,11):
    print(no)

#  1~100 중 5의배수 출력하기
for i in range(1,101):
    if i % 5 == 0 :
        print(i)

# while 구문 : 나무찍은 횟수 1씩 증가
treeHit = 0
while treeHit < 10 :
    treeHit += 1
    print("찍은횟수",treeHit)
    if treeHit == 10 :
        print("미션완료")

# for문으로 변경 (미션완료해도 100번까지 반복함, 단 break 구문 넣으면 멈춤=while 과 동일하게됨)

treeHit = 0
for i in range(1,101):
    treeHit += 1
    print("찍은횟수:", treeHit)
    if treeHit == 10 :
        print("미션완료")
        break
